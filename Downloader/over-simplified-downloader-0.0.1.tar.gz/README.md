Created by Paul A. Gureghian in July 2022.

To install this Python package either pass the source tar.gz file to pip, or run 'pip install .' from within the project root folder. you can also git clone the repo and install it with pip.

Then verify the package is installed user globally with 'which download' or 'download -h' in a terminal.

The package needs 1 parameter argument which is 'url' which is the URL you want to donwload from. 
